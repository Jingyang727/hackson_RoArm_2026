# 成功电脑配置迁移包（不安装或升级Python环境）

本包复制成功电脑2026-11-16导出的在用数据。使用同一套机械臂、相机，且相机、底座和桌面位置保持不变时使用。

解压后进入本文件所在目录，用普通用户的python3执行。无需git、pip或sudo；不会打开设备，不会发送运动或复位。

1. 先查看本包完整性及本机差异（compare发现不同返回退出码1，是正常诊断结果）：

    python3 tools/install_layout.py verify
    python3 tools/install_layout.py compare

2. 结束现有任务、等待机械臂静止，并停止网页服务。然后备份并导入配置：

    python3 tools/install_layout.py install

3. 用原目录和原Python重新启动网页服务，然后核对实际加载：

    python3 tools/install_layout.py compare --controller http://127.0.0.1:8765

核对：matches_snapshot=true、calibration_matches=true、runtime.session_path_matches_local=true、runtime.fingerprint_matches_snapshot=true。
local_policies应为单球v64、挑战v13，parameters_match均为true。确认后再在网页开始测试。

若install提示experiments目录Permission denied，先用ls -ld ~/.evoarm/rsi/experiments查看所有者。
只有确认该目录误属root时，执行以下两条命令修复该目录自身，不递归改整个.evoarm：

    sudo chown "$(id -u):$(id -g)" "$HOME/.evoarm/rsi/experiments"
    chmod u+rwx "$HOME/.evoarm/rsi/experiments"

然后用普通用户重新install。不要用sudo运行整个导入程序。新脚本会先检查所有待写目录，权限不足时不写入配置。

标定指纹：05368598e3e0f107d87f4f4d174a2cfaf88fdf9efffd91f97b0fbccb9dd7eed4。
compare使用的是当前用户目录；若网页用另一用户启动，运行路径核验会指出不同。不要用sudo运行导入程序。

导入只复制活动指针、session、参考图、单球策略、挑战策略和参考内参，共6个文件。
不同的原文件先保存到~/.evoarm/rsi/layout_backups/，写入失败会回滚；相同文件不重复写入。
历史成功试次只保留在包里作为来源证据，不安装到同事电脑的执行历史。不包含token，不更改API、串口或环境配置。

本包不包含程序代码部署，也不改变原有代码。代码应为已合入main的连续挑战版本。
成功电脑4aad187与main的8d15d54代码树相同；后续只增加配置归档的main提交号可以不同。
本包源导出与本机文件的SHA256均可核验。继续学习后策略发生变化，再次compare可能不同，不表示标定自动丢失。

SUCCESS_DEMO_COMPUTER_MANIFEST.json记录8个原始文件的SHA256；PACKAGE_MANIFEST.json另记录整个迁移包文件的SHA256。
若核对仍失败，将compare输出回传，不要重复抓取来猜是哪份文件。
